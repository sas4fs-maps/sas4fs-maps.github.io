Exadel AMF-serializer, library for AMF0/AMF3 messages
serialization/deserialization

Version 1.0.0, 1 February 2008

This software is distributed under the terms of the 
FSF Lesser GNU Public License (see license.txt).
