
===================================================

OpenAMF - Java Flash Remoting

   http://www.openamf.org

   http://www.sourceforge.net/projects/openamf

===================================================


INTRO
=====
This is the distribution of the OpenAMF project.  


LICENSE
========
OpenAMF is licensed under the GNU Lesser General Public License (LGPL) Version 2.1
(http://www.gnu.org/copyleft/lesser.txt)


GETTING STARTED
================
1. Copy openamf.war to your Tomcat webapps directory or JBoss deploy directory
2. Point your browser at http://localhost:8080/openamf/examples/client2.html
3. Click "Add Person"
4. Click "Get with Name", if you get results everything is working


USING IN YOUR OWN PROJECT
=========================
1. Copy openamf.jar to your WEB-INF/lib directory
2. Copy /src/web/WEB-INF/openamf-config.xml to your WEB-INF directory
3. Copy /src/web/WEB-INF/build-webservice.xml to your WEB-INF directory
4. Add an entry to your WEB-INF/web.xml file. Here's an example:

	<servlet>
		<servlet-name>DefaultGateway</servlet-name>
		<display-name>DefaultGateway</display-name>
		<description>DefaultGateway</description>
		<servlet-class>org.openamf.DefaultGateway</servlet-class>
		<init-param>
			<param-name>OPENAMF_CONFIG</param-name>
			<param-value>/WEB-INF/openamf-config.xml</param-value>
			<description>Location of the OpenAMF config file.</description>
		</init-param>
	</servlet>

	<servlet-mapping>
		<servlet-name>DefaultGateway</servlet-name>
		<url-pattern>/gateway</url-pattern>
	</servlet-mapping>
	
5. External Dependencies 
	- add the required jar's depending on your planned use
	- for more information please read the next section
	

EXTERNAL DEPENDENCIES
========================
The OpenAMF project makes use of several other open source projects.  Depending 
on your planned use of OpenAMF you will need to include different jar files in 
your WEB-INF/lib directory.  

If you are not sure which to add you can add them all, the only side effect will 
be the increased size of your war file.

Basic Use - DefaultGateway
---------------------------
This is designed to be a drop in replacement for MM propietary Java Flash 
Remoting.

astranslator.jar (1.5.9)
website: http://carbonfive.sourceforge.net/astranslator/api/com/carbonfive/flash/package-summary.html#documentation
Used to translate ASObjects to JavaBeans and other type conversion

commons-digester.jar (1.6)
website: http://jakarta.apache.org/commons/digester
Used to parse the opeanamf-config.xml file

commons-logging.jar (1.0.4)
website: http://jakarta.apache.org/commons/logging
Used for generic logging

commons-beanutils.jar (1.7.0)
website: http://jakarta.apache.org/commons/beanutils
Used de/serializing of JavaBeans

commons-collections.jar (3.1)
website: http://jakarta.apache.org/commons/collections
Dependency of commons-beanutils.jar

commons-lang.jar (2.1)
website: http://jakarta.apache.org/commons/lang
Used for J2SE 1.3 compatible nested exceptions

AdvancedGateway
---------------
This is an extension of the DefaultGateway that allow for advanced configuration 
and abstraction of services. 

Basic Use + 

WebServices
---------------
Basic Use +
axis.jar (1.1)
saaj.jar (from axis dist)
wsdl4j.jar (from axis dsit)
commons-discovery.jar (from axis dist)
jaxrpc.jar (from axis dist)
website: http://ws.apache.org/axis/
http://jakarta.apache.org/commons/discovery.html
http://www-124.ibm.com/developerworks/projects/wsdl4j/

Other
-------
commons-httpclient-3.0.jar (3.0)
ant.jar (1.5.4)
servlet.jar (2.3)
mysql-connector-java-3.0.6-stable-bin.jar 
jboss-j2ee.jar (?)
jboss-jmx.jar (?)

Logging
=======
The OpenAMF project makes use of the Apache Jakarta commmons-logging project 
for its logging.  

This allow us to work with any of the popular logging systems such as log4j or 
java.util.logging in J2SE 1.4

Logging config for JBoss
========================
To view debug log messages while using JBoss you will need to modify 
the {JBOSS_HOME}/server/default/conf/log4j.xml file
1. First look for this:
  <appender name="CONSOLE" class="org.apache.log4j.ConsoleAppender">
    <param name="Threshold" value="INFO"/>
    <param name="Target" value="System.out"/>

    <layout class="org.apache.log4j.PatternLayout">
      <!-- The default pattern: Date Priority [Category] Message\n -->
      <param name="ConversionPattern" value="%d{ABSOLUTE} %-5p [%c{1}:%L] %m%n"/>
    </layout>
 </appender>
2. Change the Threshold to DEBUG
3. Then further down in the file add this
  <category name="org.jboss">
    <priority value="INFO"/>
  </category>
  <category name="org.openamf">
    <priority value="DEBUG"/>
  </category>


Logging config for Tomcat
=========================
To view debug messages while using Tomcat you will need to 
set the CATALINA_OPTS environment variable to 
"-Dorg.apache.commons.logging.Log=org.apache.commons.logging.impl.SimpleLog -Dorg.apache.commons.logging.simplelog.defaultlog=debug"

After setting the environment variable you will need to restart Tomcat

All the debug message will be sent to the {TOMCAT_HOME}/logs/catalinia.out file

GETTING INVOLVED
================
Subscribe to the openamf-user and/or openamf-developer lists
http://sourceforge.net/mail/?group_id=77268

CREDITS
=======
Kevin Baker, Mission Vi Inc - Test flash clients, OpenAMF logo and website
Jason Calabrese, Mission Vi Inc - Major Enhancements, Refactoring, bug fixes
Pat Maddox - Initial port of amfphp code
Adrian Roston - WebServices, debugging, and flash test clients
Roberto Saccon - XML data type, Stateless Session EJB's and JMX
Sylwester Lachiewicz - Enhancements, Refactoring, bug fixes, partial javadoc
Sean C. Sullivan - bug fixes, enhancements, javadoc improvements
Darin Wilson - added code for serializing and deserializing long String's
