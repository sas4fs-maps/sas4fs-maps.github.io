OpenAMF - Java Flash Remoting
www.openamf.org
www.sourceforge.net/projects/openamf
================================

INTRO
=====
This is the distribution of the OpenAMF project.  


LICENSE
========
OpenAMF is licensed under the GNU General Public License (GPL) Version 2


GETTING STARTED
================
1. Copy openamf.war to your tomcat webapps directory or JBoss deploy directory
2. Point your browser at http://localhost:8080/openamf/examples/client2.html
3. Click "Add Person"
4. Click "Get with Name", if you get results everything is working


USING IN YOUR OWN PROJECT
=========================
1. Copy openamf.jar to your WEB-INF/lib directory
2. Copy /src/web/WEB-INF/openamf-config.xml to your WEB-INF directory
3. Copy /src/web/WEB-INF/build-webservice.xml to your WEB-INF directory
4. Add an entry to your WEB-INF/web.xml file, here's an example
	<servlet>
		<servlet-name>DefaultGateway</servlet-name>
		<display-name>DefaultGateway</display-name>
		<description>DefaultGateway</description>
		<servlet-class>org.openamf.DefaultGateway</servlet-class>
		<init-param>
			<param-name>OPENAMF_CONFIG</param-name>
			<param-value>/WEB-INF/openamf-config.xml</param-value>
			<description>Location of the OpenAMF config file.</description>
		</init-param>
	</servlet>

	<servlet-mapping>
		<servlet-name>DefaultGateway</servlet-name>
		<url-pattern>/gateway</url-pattern>
	</servlet-mapping>
5. External Dependencies 
	- add the required jar's depending on your planed use
	- for more information please read the next section
	

EXTERNAL DEPENDENCIES
========================
The OpenAMF Project makes use of several other open source projects.  Depending 
on your planned use of OpenAMF you will need to include different jar files in 
your WEB-INF/lib directory.  

If your not sure which to add you can added them all, the only side effect will 
be the increased size of your war file.

Basic Use - DefaultGateway
---------------------------
This is designed to be a drop in replacement for MM propietary Java Flash 
Remoting.

commons-logging.jar
website: http://jakarta.apache.org/commons/logging.html
Used for generic logging

commons-beanutils.jar
website: http://jakarta.apache.org/commons/beanutils.html
Used de/serializing of JavaBeans

commons-collections.jar
website: http://jakarta.apache.org/commons/collections.html
Dependency of commons-beanutils.jar

AdvancedGateway
---------------------
This is an extension of the DefaultGateway that allow for advanced configuration 
and abstraction of services. 

Basic Use + 
commons-digester.jar
website: http://jakarta.apache.org/commons/digester.html
Used for parsing xml config file into Java Objects

WebServices
---------------
Basic Use +
axis.jar
saaj.jar
website: http://ws.apache.org/axis/

commons-discovery.jar
http://jakarta.apache.org/commons/discovery.html

wsdl4j.jar
http://www-124.ibm.com/developerworks/projects/wsdl4j/

Logging
=======
The OpenAMF project makes use of the Apache Jakarta commmons-logging project 
for its logging.  

This allow us to work with any of the popular logging systems such as Log4J or 
the JDK 1.4 Logger.

Logging config for JBOSS
-----------------------------
To view debug log messages while using JBoss you will need to modify 
the {JBOSS_HOME}/server/default/conf/log4j.xml file
1. First look for this:
  <appender name="CONSOLE" class="org.apache.log4j.ConsoleAppender">
    <param name="Threshold" value="INFO"/>
    <param name="Target" value="System.out"/>

    <layout class="org.apache.log4j.PatternLayout">
      <!-- The default pattern: Date Priority [Category] Message\n -->
      <param name="ConversionPattern" value="%d{ABSOLUTE} %-5p [%c{1}:%L] %m%n"/>
    </layout>
 </appender>
2. Change the Threshold to DEBUG
3. Then further down in the file add this
  <category name="org.jboss">
    <priority value="INFO"/>
  </category>
  <category name="org.apache">
    <priority value="INFO"/>
  </category>


Logging config for Tomcat
-----------------------------
To view debug messages while using Tomcat you will need to 
set the CATALINA_OPTS environment variable to 
"-Dorg.apache.commons.logging.Log=org.apache.commons.logging.impl.SimpleLog -Dorg.apache.commons.logging.simplelog.defaultlog=debug"

After setting the environment variable you will need to restart Tomcat

All the debug message will be sent to the {TOMCAT_HOME}/logs/catalinia.out file

GETTING INVOLVED
=================
Subscribe to the openamf-user and/or openamf-developer lists
http://sourceforge.net/mail/?group_id=77268

CREDITS
=======
Kevin Baker, Mission Vi Inc - Test flash clients, OpenAMF logo and website
Jason Calabrese, Mission Vi Inc - Major Enhancements, Refactoring, bug fixes
Pat Maddox - Initial port of amfphp code
Adrian Roston - WebServices, debugging, and flash test clients
Roberto Saccon - XML data type, Stateless Session EJB's and JMX


