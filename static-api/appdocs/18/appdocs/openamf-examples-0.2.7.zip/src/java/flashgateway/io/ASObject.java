package flashgateway.io;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class ASObject extends HashMap {
	
	private String type;
	
	public ASObject() {
		super();
	}

	public ASObject(String type) {
		super();
		this.type = type;
	}
	
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}

	public boolean containsKey(Object key) {
		return super.containsKey(toLowerCase(key));
	}

	public Object get(Object key) {
		return super.get(toLowerCase(key));
	}

	public Object put(Object key, Object value) {
		return super.put(toLowerCase(key), value);
	}

	public void putAll(Map map) {
		for (Iterator i = map.entrySet().iterator(); i.hasNext();) {
			Map.Entry entry = (Map.Entry)i.next();
			put(toLowerCase(entry.getKey()), entry.getValue());
		}
	}

	public Object remove(Object key) {
		return super.remove(toLowerCase(key));
	}
	
	private Object toLowerCase(Object key) {
		
		if (key != null & key instanceof String) {
			key = ((String)key).toLowerCase();
		}
		
		return key;		
	}

}
