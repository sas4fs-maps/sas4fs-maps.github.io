package org.openamf.invoker;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import javax.servlet.ServletContext;

import org.openamf.ServiceRequest;
;

public abstract class ServiceInvoker {

	protected ServiceRequest request;
	protected ServletContext servletContext;
	protected Object persistantServiceObject;

	public ServiceInvoker(
		ServiceRequest request,
		ServletContext servletContext) {

		this.request = request;
		this.servletContext = servletContext;
	}

	public abstract Object invokeService() throws ServiceInvocationException;

	public ServiceRequest getRequest() {
		return request;
	}

	public void setRequest(ServiceRequest request) {
		this.request = request;
	}

	public ServletContext getServletContext() {
		return servletContext;
	}

	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;
	}

	public boolean getPersistService() {
		return false;
	}

	public String getPersistantServiceName() {
		return null;
	}

	public Object getPersistantServiceObject() {
		return persistantServiceObject;
	}

	public void setPersistantServiceObject(Object persistantServiceObject) {
		this.persistantServiceObject = persistantServiceObject;
	}

	public abstract boolean supports(ServiceRequest request);

	public static ServiceInvoker load(
		String className,
		ServiceRequest request,
		ServletContext servletContext)
		throws
			ClassNotFoundException,
			NoSuchMethodException,
			InstantiationException,
			IllegalAccessException,
			InvocationTargetException {

		ServiceInvoker serviceInvoker;
		Class serviceInvokerClass =
			Thread.currentThread().getContextClassLoader().loadClass(className);

		Constructor constructor =
			serviceInvokerClass.getConstructor(
				new Class[] { ServiceRequest.class, ServletContext.class });

		serviceInvoker =
			(ServiceInvoker) constructor.newInstance(
				new Object[] { request, servletContext });
		return serviceInvoker;
	}

}
