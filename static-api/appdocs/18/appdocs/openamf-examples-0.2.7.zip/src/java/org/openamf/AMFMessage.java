package org.openamf;

import java.util.ArrayList;
import java.util.Iterator;

public class AMFMessage {
	// The headers
	protected ArrayList headers;

	// The body objects
	protected ArrayList bodies;

	public AMFMessage() {
		headers = new ArrayList();
		bodies = new ArrayList();
	}

	public void addHeader(String key, boolean required, Object value) {
		headers.add(new AMFHeader(key, required, value));
	}

	public int getHeaderCount() {
		return headers.size();
	}

	public void addBody(
		String target,
		String response,
		Object value,
		byte type) {
		addBody(new AMFBody(target, response, value, type));
	}

	public void addBody(AMFBody body) {
		bodies.add(body);
	}

	public int getBodyCount() {
		return bodies.size();
	}

	public AMFBody getBodyAt(int i) {
		return (AMFBody) bodies.get(i);
	}

	public Iterator getBodies() {
		return bodies.iterator();		
	}
	public AMFHeader getHeaderAt(int i) {
		return (AMFHeader) headers.get(i);
	}

}