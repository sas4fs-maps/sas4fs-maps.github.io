/*
 * Created on Apr 26, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package org.openamf.invoker;

import javax.servlet.ServletContext;

import org.openamf.ServiceRequest;
import org.openamf.recordset.ASRecordSet;

/**
 * @author jason
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class PageableResultSetServiceInvoker extends ServiceInvoker {

	public PageableResultSetServiceInvoker(
		ServiceRequest request,
		ServletContext servletContext) {
		super(request, servletContext);
	}

	public Object invokeService() throws ServiceInvocationException {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean supports(ServiceRequest request) {
		return request.getServiceName().equals(ASRecordSet.SERVICE_NAME);
	}

}
