package org.openamf.invoker;

import java.lang.reflect.Method;

import javax.ejb.EJBHome;
import javax.ejb.EJBObject;
import javax.naming.InitialContext;
import javax.servlet.ServletContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openamf.ServiceRequest;

public class SLSBServiceInvoker extends JavaServiceInvoker {

	private static Log log = LogFactory.getLog(SLSBServiceInvoker.class);

	public SLSBServiceInvoker(
		ServiceRequest request,
		ServletContext servletContex) {

		super(request, servletContex);
	}

	public Object invokeService() throws ServiceInvocationException {

		Object serviceResult = null;

		try {
			InitialContext context = new InitialContext();
			Object home = context.lookup(request.getServiceName());
			Method ejbCreateMethod =
				home.getClass().getMethod("create", new Class[0]);
			EJBObject ejb =
				(EJBObject) ejbCreateMethod.invoke(home, new Object[0]);
			serviceResult =
				invokeServiceMethod(
					ejb,
					ejb.getClass(),
					request.getServiceMethodName(),
					request.getParameters());
		} catch (Exception e) {
			throw new ServiceInvocationException(request, e);
		}

		return serviceResult;

	}

	public boolean supports(ServiceRequest request) {
		boolean supports = false;
		try {
			supports =
				((new InitialContext()).lookup(request.getServiceName())
					instanceof EJBHome);
		} catch (Exception e) {
		}

		return supports;
	}

}
