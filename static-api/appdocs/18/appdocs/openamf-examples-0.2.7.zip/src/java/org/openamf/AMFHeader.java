package org.openamf;

public class AMFHeader {
	protected String key;
	protected boolean required;
	protected Object value;

	public AMFHeader(String key, boolean required, Object value) {
		this.key = key;
		this.required = required;
		this.value = value;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public boolean isRequired() {
		return required;
	}

	public void setRequired(boolean required) {
		this.required = required;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}
}