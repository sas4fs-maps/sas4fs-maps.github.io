package org.openamf.invoker;

import org.openamf.AMFBody;
import org.openamf.ServiceRequest;
import org.openamf.AMFError;

public class ServiceInvocationException extends Exception {

	protected AMFBody requestBody;
	protected ServiceRequest request;
	protected Throwable cause;

	public ServiceInvocationException(
		AMFBody requestBody,
		Throwable cause) {

		super(cause);

		this.cause = cause;
		this.requestBody = requestBody;
	}
	
	public ServiceInvocationException(
		ServiceRequest request,
		Throwable cause) {

		super(cause);

		this.cause = cause;
		this.request = request;
	}
	public AMFError getAMFError() {
		
		AMFError amfError = new AMFError();
		
		StackTraceElement[] stackTrace = cause.getStackTrace();
		StringBuffer stackTraceBuffer = new StringBuffer();
		for (int i = 0; i < stackTrace.length; i++) {
			StackTraceElement element = stackTrace[i];
			stackTraceBuffer.append(element.toString());
			stackTraceBuffer.append('\n');
		}		
		
		amfError.setCode("SERVER.PROCESSING");
		amfError.setLevel("error");
		amfError.setType(stackTraceBuffer.toString());
		
		return amfError;
		
	}

}
