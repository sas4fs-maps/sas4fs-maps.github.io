package org.openamf.config;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.digester.Digester;
import org.xml.sax.SAXException;

public class ConfigDigester extends Digester {

	private static final String INVOKER_PATH = "config/invoker";
	private static final String SERVICE_PATH = "config/service";
	private static final String METHOD_PATH = SERVICE_PATH + "/method";
	private static final String METHOD_PARAM_PATH =
		METHOD_PATH + "/parameter";
	private static final String RESULT_FILTER_PATH =
		METHOD_PATH + "/result-filter";
	private static final String RESULT_FILTER_PARAM_PATH =
		RESULT_FILTER_PATH + "/parameter";
	private static final String STATE_BEAN_PATH = "config/state-bean";

	protected boolean configured = false;

	public Object parse(InputStream input) throws IOException, SAXException {
		configure();
		return (super.parse(input));

	}

	protected void configure() {

		if (configured) {
			return;
		}

		addObjectCreate("config", Config.class);

		addInvokerRules();
		addServiceRules();
		addServiceMethodRules();
		addResultTranslatorRules();
		addStateBeanRules();

		// Mark this digester as having been configured
		configured = true;

	}

	private void addInvokerRules() {
		addObjectCreate(INVOKER_PATH, ServiceInvokerConfig.class);
		addSetNext(
			INVOKER_PATH,
			"addServiceInvokerConfig",
			"org.openamf.config.ServiceInvokerConfig");
		addCallMethod(INVOKER_PATH + "/name", "setName", 0);
		addCallMethod(INVOKER_PATH + "/class", "setClassName", 0);
	}

	private void addServiceRules() {
		addObjectCreate(SERVICE_PATH, ServiceConfig.class);
		addSetNext(
			SERVICE_PATH,
			"addServiceConfig",
			"org.openamf.config.ServiceConfig");
		addCallMethod(SERVICE_PATH + "/name", "setName", 0);
		addCallMethod(
			SERVICE_PATH + "/service-location",
			"setServiceLocation",
			0);
		addCallMethod(SERVICE_PATH + "/invoker-ref", "setServiceInvokerRef", 0);
	}

	private void addServiceMethodRules() {
		addObjectCreate(METHOD_PATH, ServiceMethodConfig.class);
		addSetNext(
			METHOD_PATH,
			"addMethodConfig",
			"org.openamf.config.ServiceMethodConfig");
		addCallMethod(METHOD_PATH + "/name", "setName", 0);
		addCallMethod(
			METHOD_PATH + "/state-bean-ref/name",
			"addStateBeanRef",
			0);
		addObjectCreate(
			METHOD_PARAM_PATH,
			ServiceMethodParameterConfig.class);
		addSetNext(
			METHOD_PARAM_PATH,
			"addParameterConfig",
			"org.openamf.config.ServiceMethodParameterConfig");
		addCallMethod(METHOD_PARAM_PATH + "/type", "setType", 0);
	}

	private void addResultTranslatorRules() {
		addObjectCreate(RESULT_FILTER_PATH, FilterConfig.class);
		addSetNext(
			RESULT_FILTER_PATH,
			"addResultFilterConfig",
			"org.openamf.config.FilterConfig");
		addCallMethod(RESULT_FILTER_PATH + "/class", "setClassName", 0);
		addObjectCreate(
			RESULT_FILTER_PARAM_PATH,
			FilterParameterConfig.class);
		addSetNext(
		RESULT_FILTER_PARAM_PATH,
			"addParameterConfig",
			"org.openamf.config.FilterParameterConfig");
		addCallMethod(RESULT_FILTER_PARAM_PATH + "/name", "setName", 0);
		addCallMethod(RESULT_FILTER_PARAM_PATH + "/value", "setValue", 0);
	}

	private void addStateBeanRules() {
		addObjectCreate(STATE_BEAN_PATH, StateBeanConfig.class);
		addSetNext(
			STATE_BEAN_PATH,
			"addStateBeanConfig",
			"org.openamf.config.StateBeanConfig");
		addCallMethod(STATE_BEAN_PATH + "/name", "setName", 0);
		addCallMethod(STATE_BEAN_PATH + "/class", "setClassName", 0);
		addCallMethod(STATE_BEAN_PATH + "/scope", "setScope", 0);
	}

}
