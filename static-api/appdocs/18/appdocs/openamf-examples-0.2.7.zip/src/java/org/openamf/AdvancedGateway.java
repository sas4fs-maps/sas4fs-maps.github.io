package org.openamf;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openamf.config.Config;
import org.openamf.config.ServiceConfig;
import org.openamf.config.ServiceMethodConfig;
import org.openamf.config.ServiceMethodParameterConfig;
import org.openamf.config.StateBeanConfig;
import org.openamf.config.FilterConfig;
import org.openamf.invoker.ServiceInvocationException;
import org.openamf.invoker.ServiceInvoker;
import org.openamf.filter.FilterException;
import org.openamf.filter.ResultFilter;
import org.xml.sax.SAXException;

public class AdvancedGateway extends DefaultGateway {

	private static Log log = LogFactory.getLog(AdvancedGateway.class);

	protected ServiceInvoker getServiceInvoker(
		AMFBody requestBody,
		HttpServletRequest httpServletRequest)
		throws ServiceInvocationException {

		ServiceInvoker serviceInvoker = null;

		try {
			ServiceConfig serviceConfig = getServiceConfig(requestBody);

			ServiceRequest request =
				new ServiceRequest(requestBody, serviceConfig);

			ServiceMethodConfig methodConfig =
				getMethodConfig(serviceConfig, request);

			addStateBeansToParams(httpServletRequest, request, methodConfig);
			
			serviceInvoker =
				ServiceInvoker.load(
					serviceConfig.getServiceInvokerConfig().getClassName(),
					request,
					getServletContext());

		} catch (Exception e) {
			throw new ServiceInvocationException(requestBody, e);
		}

		return serviceInvoker;
	}

	private void addStateBeansToParams(
		HttpServletRequest httpServletRequest,
		ServiceRequest request,
		ServiceMethodConfig methodConfig)
		throws
			ClassNotFoundException,
			InstantiationException,
			IllegalAccessException {

		if (methodConfig != null) {
			Iterator stateBeans = methodConfig.getStateBeanConfigs();
			while (stateBeans.hasNext()) {

				Object stateBean = null;
				StateBeanConfig stateBeanConfig =
					(StateBeanConfig) stateBeans.next();

				if (stateBeanConfig.isApplcationScope()) {
					stateBean =
						getServletContext().getAttribute(
							stateBeanConfig.getClassName());
				} else {
					stateBean =
						httpServletRequest.getSession().getAttribute(
							stateBeanConfig.getClassName());
				}

				if (stateBean == null) {
					log.debug("loading " + stateBeanConfig.getClassName());
					Class stateBeanClass =
						Thread
							.currentThread()
							.getContextClassLoader()
							.loadClass(
							stateBeanConfig.getClassName());
					stateBean = stateBeanClass.newInstance();

					if (stateBeanConfig.isApplcationScope()) {
						log.debug(
							"storing "
								+ stateBeanConfig.getClassName()
								+ " in ServletContext");
						getServletContext().setAttribute(
							stateBeanConfig.getClassName(),
							stateBean);
					} else {
						log.debug(
							"storing "
								+ stateBeanConfig.getClassName()
								+ " in HttpSession");
						httpServletRequest.getSession().setAttribute(
							stateBeanConfig.getClassName(),
							stateBean);
					}
				} else {
					if (stateBeanConfig.isApplcationScope()) {
						log.debug(
							"got "
								+ stateBeanConfig.getClassName()
								+ " from ServletContext");
					} else {
						log.debug(
							"got "
								+ stateBeanConfig.getClassName()
								+ " from HttpSession");
					}
				}

				request.addParameter(stateBean);
			}
		}
	}

	protected Object postInvokeService(
		HttpServletRequest httpServletRequest,
		ServiceInvoker serviceInvoker,
		Object serviceResult)
		throws ServiceInvocationException {

		ServiceMethodConfig methodConfig =
			serviceInvoker.getRequest().getServiceMethodConfig();

		try {
			if (methodConfig != null) {
				Iterator rfcs = methodConfig.getResultFilterConfigs();
				while (rfcs.hasNext()) {
					FilterConfig fc = (FilterConfig) rfcs.next();
					serviceResult = filterResult(serviceResult, fc);
				}
			}

		} catch (Exception e) {
			throw new ServiceInvocationException(
				serviceInvoker.getRequest(),
				e);
		}

		return super.postInvokeService(
			httpServletRequest,
			serviceInvoker,
			serviceResult);
	}

	private Object filterResult(
		Object serviceResult,
		FilterConfig translatorConfig)
		throws
			ClassNotFoundException,
			InstantiationException,
			IllegalAccessException,
			FilterException {

		log.debug(
			"loading translator class: " + translatorConfig.getClassName());
		Class translatorClass =
			Thread.currentThread().getContextClassLoader().loadClass(
				translatorConfig.getClassName());

		ResultFilter resultFilter = (ResultFilter) translatorClass.newInstance();

		log.debug("calling translate");
		return resultFilter.filter(serviceResult, translatorConfig);

	}

	private ServiceConfig getServiceConfig(AMFBody requestBody)
		throws IOException, SAXException {

		Config config = getConfig();

		ServiceConfig serviceConfig =
			config.getServiceConfig(requestBody.getServiceName());

		return serviceConfig;
	}

	private ServiceMethodConfig getMethodConfig(
		ServiceConfig serviceConfig,
		ServiceRequest request)
		throws IOException, SAXException, ClassNotFoundException {

		log.debug("getting OperationConfig");
		log.debug("looking for " + request.getServiceMethodName());

		ServiceMethodConfig methodConfig = null;

		ArrayList parameters = request.getParameters();

		Iterator smcs = serviceConfig.getMethodConfigs();

		smcsLabel : while (smcs.hasNext()) {

			ServiceMethodConfig smc = (ServiceMethodConfig) smcs.next();
			log.debug("soc name: " + smc.getName());
			if (smc.getName().equals(request.getServiceMethodName())) {
				log.debug("name matches, now to compare params");
				//compare params
				int paramIndex = -1;
				Iterator sopcs = smc.getParameterConfigs();

				smpcsLabel : while (sopcs.hasNext()) {
					paramIndex++;
					ServiceMethodParameterConfig sopc =
						(ServiceMethodParameterConfig) sopcs.next();
					if (sopc.getType().equals("*")) {
						log.debug("matches the rest");
						methodConfig = smc;
						break smcsLabel;
					} else if (
						sopc.getType().equals("?")
							|| typesMatch(parameters, paramIndex, sopc)) {
						if (paramIndex == parameters.size()) {
							log.debug("all parameters match");
							methodConfig = smc;
							break smcsLabel;
						} else {
							log.debug(
								"this parameter matches, contine checking the rest");
							continue smpcsLabel;
						}
					}
				}
			}
		}

		//store methodConfig in request so we don't have to get it again
		request.setServiceMethodConfig(methodConfig);

		return methodConfig;
	}

	private boolean typesMatch(
		ArrayList parameters,
		int paramIndex,
		ServiceMethodParameterConfig sopc)
		throws ClassNotFoundException {

		boolean typesMatch = false;

		Class typeClass =
			Thread.currentThread().getContextClassLoader().loadClass(
				sopc.getType());
		if (typeClass.isInstance(parameters.get(paramIndex))) {
			typesMatch = true;
		}

		return typesMatch;
	}

}
