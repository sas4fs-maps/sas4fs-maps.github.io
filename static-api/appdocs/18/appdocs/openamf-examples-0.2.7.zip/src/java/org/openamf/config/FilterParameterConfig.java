package org.openamf.config;

public class FilterParameterConfig {
	
	private String name;
	private String value;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String toString() {
		
		StringBuffer sb = new StringBuffer();
		
		sb.append("\t\t\tName: ");
		sb.append(getName());
		sb.append('\n');
		
		sb.append("\t\t\tValue: ");
		sb.append(getValue());
		sb.append('\n');
		return sb.toString();
	}


}
