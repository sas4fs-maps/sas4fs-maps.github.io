package org.openamf.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class Config {

	private HashMap serviceConfigs = new HashMap();
	private ArrayList serviceInvokerConfigs = new ArrayList();
	private HashMap stateBeanConfigs = new HashMap();

	public void addServiceInvokerConfig(ServiceInvokerConfig serviceInvokerConfig) {
		serviceInvokerConfigs.add(serviceInvokerConfig);
	}

	public ServiceInvokerConfig getServiceInvokerConfig(String name) {
		
		ServiceInvokerConfig serviceInvokerConfig = null;
		
		for (Iterator i = getServiceInvokerConfigs(); i.hasNext();) {
			ServiceInvokerConfig sic = (ServiceInvokerConfig)i.next();
			if (sic.getName().equals(name)) {
				serviceInvokerConfig = sic;
				break;
			}
		}
		return serviceInvokerConfig;
	}
	
	public Iterator getServiceInvokerConfigs() {
		return serviceInvokerConfigs.iterator();
	}
	
	public void addServiceConfig(ServiceConfig serviceConfig) {
		serviceConfig.setConfig(this);
		serviceConfigs.put(serviceConfig.getName(), serviceConfig);
	}

	public ServiceConfig getServiceConfig(String name) {
		return (ServiceConfig) serviceConfigs.get(name);
	}

	public Iterator getServiceConfigs() {
		return serviceConfigs.values().iterator();
	}
	
	public void addStateBeanConfig(StateBeanConfig stateBeanConfig) {
		stateBeanConfigs.put(stateBeanConfig.getName(), stateBeanConfig);
	}

	public StateBeanConfig getStateBeanConfig(String name) {
		return (StateBeanConfig) stateBeanConfigs.get(name);
	}

	public Iterator getStateBeanConfigs() {
		return stateBeanConfigs.values().iterator();
	}
	
	public String toString() {
		
		StringBuffer sb = new StringBuffer();
		
		sb.append("\n=================\n");
		sb.append("SERVICE INVOKERS\n");
		sb.append("=================\n");
		for (Iterator i = getServiceInvokerConfigs(); i.hasNext();) {
			ServiceInvokerConfig sic = (ServiceInvokerConfig)i.next();
			sb.append(sic);
		}
		
		sb.append("\n=========\n");
		sb.append("SERVICES\n");
		sb.append("=========\n");
		for (Iterator i = getServiceConfigs(); i.hasNext();) {
			ServiceConfig sc = (ServiceConfig)i.next();
			sb.append(sc);
		}
		
		sb.append("\n=========\n");
		sb.append("STATE BEANS\n");
		sb.append("=========\n");
		for (Iterator i = getStateBeanConfigs(); i.hasNext();) {
			StateBeanConfig sbc = (StateBeanConfig)i.next();
			sb.append(sbc);
		}
		
		return sb.toString();
	}	

}
