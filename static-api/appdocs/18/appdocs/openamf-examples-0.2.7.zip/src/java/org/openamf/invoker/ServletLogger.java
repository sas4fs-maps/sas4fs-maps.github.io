/*
 * Created on Apr 20, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package org.openamf.invoker;

//import java.io.*;
import java.util.*;
//import java.text.*;

import javax.servlet.*;
//import javax.servlet.http.*;

import org.apache.tools.ant.*;
//import org.apache.tools.ant.input.*;
import org.apache.tools.ant.util.*;


public class ServletLogger implements BuildListener {
  private GenericServlet servlet;
  private long startTime = System.currentTimeMillis();

  public ServletLogger( GenericServlet servlet) {
    this.servlet = servlet;
  }
  
public ServletLogger(){}



  public void buildStarted( BuildEvent event) {
    startTime = System.currentTimeMillis();
   // servlet.log( "BUILD STARTED");
   System.out.println("build started");
  }

  public void buildFinished( BuildEvent event) {
    Throwable error = event.getException();
    StringBuffer message = new StringBuffer();

    if( error==null) {
      message.append( StringUtils.LINE_SEP);
      message.append( "BUILD SUCCESSFUL");
    
    } else {
      message.append( StringUtils.LINE_SEP);
      message.append( "BUILD FAILED");
      message.append( StringUtils.LINE_SEP);

      if( !( error instanceof BuildException)) {
        message.append( StringUtils.getStackTrace( error));
      
      } else {
        if( error instanceof BuildException) {
          message.append( error.toString()).append( StringUtils.LINE_SEP);
        } else {
          message.append( error.getMessage()).append( StringUtils.LINE_SEP);
        }
      }

    }
    message.append( StringUtils.LINE_SEP);
    message.append( "Total time: ");
    message.append(( System.currentTimeMillis()-startTime)/1000);

    //System.out.println( message.toString());
  }

  public void targetStarted( BuildEvent event) {
    //System.out.println( StringUtils.LINE_SEP+event.getTarget().getName()+":");
  }

  public void targetFinished( BuildEvent event) {
    // System.out.println();
  }

  public void taskStarted( BuildEvent event) {
    // System.out.println();
  }

  public void taskFinished( BuildEvent event) {
    // System.out.println();
  }

  public void messageLogged( BuildEvent event) {
    StringBuffer message = new StringBuffer();
    if( event.getTask()!=null) {
      // Print out the name of the task if we're in one
      String name = event.getTask().getTaskName();
      String label = "["+name +"] ";
      int size = 10-label.length();
      StringBuffer tmp = new StringBuffer();
      for( int i = 0; i < size; i++) tmp.append( " ");
      tmp.append( label);
      label = tmp.toString();

      StringTokenizer tok = new StringTokenizer( event.getMessage(), "\r\n", false);
      boolean first = true;
      while( tok.hasMoreTokens()) {
        if( !first) message.append( StringUtils.LINE_SEP);
        first = false;
        message.append( label);
        message.append( tok.nextToken());
      }

    } else {
      message.append( event.getMessage());
    }

    System.out.println( message.toString());
  }

} 
