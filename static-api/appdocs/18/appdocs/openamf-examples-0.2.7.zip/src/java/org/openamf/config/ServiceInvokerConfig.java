package org.openamf.config;

public class ServiceInvokerConfig {

	private String name;
	private String className;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String toString() {
		
		StringBuffer sb = new StringBuffer();
		
		sb.append("Name: ");
		sb.append(getName());
		sb.append('\n');
		
		sb.append("Class Name: ");
		sb.append(getClassName());
		sb.append('\n');
		
		return sb.toString();
	}

}
