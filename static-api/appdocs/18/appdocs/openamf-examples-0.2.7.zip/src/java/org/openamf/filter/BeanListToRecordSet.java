package org.openamf.filter;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openamf.config.FilterConfig;
import org.openamf.recordset.ASRecordSet;

public class BeanListToRecordSet implements ResultFilter {

	private static Log log = LogFactory.getLog(BeanListToRecordSet.class);

	public Object filter(Object value, FilterConfig config)
		throws FilterException {
		
		log.debug("Translating BeanListToRecordSet");
		
		ASRecordSet recordSet = null;
		if (value instanceof List) {
			String[] ignoreProperties = config.getParameterValues("ignore");
			recordSet = new ASRecordSet();	
			try {	
				recordSet.populate((List)value, ignoreProperties);
			} catch (Exception e) {
				throw new FilterException(e);
			}
		} else {
			throw new FilterException("value is not an instance of List");
		}
	
		return recordSet;	
	}

}
