package org.openamf.config;

import java.util.ArrayList;
import java.util.Iterator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ServiceConfig {
	
	private String name;
	private String serviceLocation;
	private String serviceInvokerRef;
	private ServiceInvokerConfig serviceInvokerConfig;
	private Config config;
	private ArrayList methodConfigs = new ArrayList(); 
	
	private static Log log = LogFactory.getLog(ServiceConfig.class);

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public String getServiceLocation() {
		return serviceLocation;
	}

	public void setServiceLocation(String string) {
		serviceLocation = string;
	}

	public String getServiceInvokerRef() {
		return serviceInvokerRef;
	}

	public void setServiceInvokerRef(String serviceInvokerRef) {
		this.serviceInvokerRef = serviceInvokerRef;
	}
	
	public ServiceInvokerConfig getServiceInvokerConfig() {
		
		if (config == null) {
			return null;
		}
		
		if (serviceInvokerConfig == null) {
			serviceInvokerConfig = config.getServiceInvokerConfig(serviceInvokerRef);
		}
		
		return serviceInvokerConfig;
	}

	public Config getConfig() {
		return config;
	}

	public void setConfig(Config config) {
		this.config = config;
	}
	
	public Iterator getMethodConfigs() {
		return methodConfigs.iterator();
	}
	
	public void addMethodConfig(ServiceMethodConfig methodConfig) {
		methodConfig.setServiceConfig(this);
		methodConfigs.add(methodConfig);
	}
	
	public String toString() {
		
		if (config == null) {
			return super.toString();
		}
		
		StringBuffer sb = new StringBuffer();
		
		sb.append("\n**************************\n");
		
		sb.append("Name: ");
		sb.append(getName());
		sb.append('\n');
		
		sb.append("Service Location: ");
		sb.append(getServiceLocation());
		sb.append('\n');
		
		sb.append("Service Invoker Ref: ");
		sb.append(getServiceInvokerRef());
		sb.append('\n');

		sb.append("Service Invoker:\n");
		sb.append(getServiceInvokerConfig());
		sb.append('\n');

		sb.append("-----------------\n");
		sb.append("METHODS\n");
		sb.append("-----------------\n");
		for (Iterator i = getMethodConfigs(); i.hasNext();) {
			ServiceMethodConfig soc = (ServiceMethodConfig)i.next();
			sb.append(soc);
		}
		
		return sb.toString();
	}

}
