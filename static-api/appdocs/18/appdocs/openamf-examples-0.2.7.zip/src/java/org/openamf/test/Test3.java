package org.openamf.test;

import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

import org.w3c.dom.Document;

public class Test3
{
	public Double getNumber(Double value)
	{
		return value;
	}

	public ArrayList getNumberArray(ArrayList value)
	{
		return value;
	}
	
	public String getString(String value)
	{
		return value;
	}

	public Date getDate(Date value)
	{
		return value;
	}
	
	public Document getXML(Document value)
	{
		return value;
	}

	public Map getPOJO(Map value)
	{
		return value;
	}	

}
