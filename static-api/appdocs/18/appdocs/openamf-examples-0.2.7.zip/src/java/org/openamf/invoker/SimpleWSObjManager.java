/*
 * Created on Apr 25, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package org.openamf.invoker;


public class SimpleWSObjManager {

private java.util.Hashtable ht=null;




public SimpleWSObjManager()
{
	
	ht=new java.util.Hashtable(89);
}

public void addSimpleWebservice(String key, SimpleWebServiceObject value)
{
	//TODO: make sure doesnt exist, and isnt null?
	ht.put(key, value);
	
	
}
public SimpleWebServiceObject getSimpleWebservice(String key)
{
	Object o=ht.get(key);
	if(o!=null)return (SimpleWebServiceObject)o;
	return null;
}



}
