package org.openamf.invoker;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openamf.ASObject;

import com.carbonfive.flash.decoder.ActionScriptDecoder;
import com.carbonfive.flash.decoder.DecoderFactory;

public class RankedMethod implements Comparable {

	public static final int NAME_MATCHES = 55;
	public static final int NAME_CASE_MATCHES = 5;
	public static final int PARAM_COUNT_MATCHES = 10;

	private double rank;
	private Method method;
	private List parameters;
	private boolean invokable;

	private static final Log log = LogFactory.getLog(RankedMethod.class);

	RankedMethod(Method method, String requestedMethodName, List parameters) {

		this.method = method;
		process(requestedMethodName, parameters);
	}

	public double getRank() {
		return rank;
	}

	public Method getMethod() {
		return method;
	}

	public boolean isInvokable() {
		return invokable;
	}

	Object invoke(Object service)
		throws
			IllegalArgumentException,
			IllegalAccessException,
			InvocationTargetException {
		return method.invoke(service, parameters.toArray());
	}

	private void process(String requestedMethodName, List parameters) {

		log.debug("comparing to methodName: " + method.getName());

		double rank = 0;
		ArrayList decodedParameters = null;

		if (method.getName().equalsIgnoreCase(requestedMethodName)) {
			log.debug("NAME_MATCHES");
			rank = RankedMethod.NAME_MATCHES;

			if (method.getName().equals(requestedMethodName)) {
				log.debug("NAME_CASE_MATCHES");
				rank += RankedMethod.NAME_CASE_MATCHES;
			}

			Class[] parameterTypes = method.getParameterTypes();
			if (parameterTypes.length == parameters.size()) {
				log.debug("PARAM_COUNT_MATCHES");
				rank += RankedMethod.PARAM_COUNT_MATCHES;

				decodedParameters = new ArrayList(parameterTypes.length);

				rank =
					checkParameters(
						parameters,
						rank,
						decodedParameters,
						parameterTypes);
			}
			log.debug("RANK: " + rank);
		}

		this.rank = rank;
		this.parameters = decodedParameters;

	}

	private double checkParameters(
		List parameters,
		double rank,
		ArrayList decodedParameters,
		Class[] parameterTypes) {

		invokable = true;

		int allParamTypesMatch =
			100 - NAME_MATCHES - NAME_CASE_MATCHES - PARAM_COUNT_MATCHES;

		double paramTypeMatchValue = 0;
		if (parameterTypes.length == 0) {
			rank += allParamTypesMatch;
		} else {
			paramTypeMatchValue = allParamTypesMatch / parameterTypes.length;
		}

		for (int i = 0; i < parameterTypes.length; i++) {
			Class parameterType = parameterTypes[i];
			Object parameter = parameters.get(i);
			
			boolean origTypesMatch = typesMatch(parameterType, parameter);

			Object decodedObject = decodeParameter(parameter, parameterType);
			if (decodedObject != null && typesMatch(parameterType, decodedObject)) {
				log.debug("types match");
				if (origTypesMatch) {
					rank += paramTypeMatchValue;
				} else {
					rank += paramTypeMatchValue / 2;
				}
				decodedParameters.add(decodedObject);
			} else if (origTypesMatch) {
				// types matched before decoding, but don't match now
				// use parameter instead of decodedObject
				rank += paramTypeMatchValue;
				decodedParameters.add(parameter);
			} else {
				log.debug("parameter couldn't be decoded");
				invokable = false;
				break;
			}
		}

		return rank;
	}
	
	private boolean typesMatch(Class parameterType, Object parameter) {
		
		log.debug("expected class: " + parameterType.getName());
		log.debug("parameter class: " + parameter.getClass().getName());
		
		boolean typesMatch = parameterType.isInstance(parameter);
		
		if (!typesMatch) {
			if (parameterType.equals(Byte.TYPE) && parameter instanceof Byte) {
				typesMatch = true;
			}
			if (parameterType.equals(Short.TYPE) && parameter instanceof Short) {
				typesMatch = true;
			}
			if (parameterType.equals(Integer.TYPE) && parameter instanceof Integer) {
				typesMatch = true;
			}
			if (parameterType.equals(Long.TYPE) && parameter instanceof Long) {
				typesMatch = true;
			}
			if (parameterType.equals(Float.TYPE) && parameter instanceof Float) {
				typesMatch = true;
			}
			if (parameterType.equals(Double.TYPE) && parameter instanceof Double) {
				typesMatch = true;
			}
		}
		
		return typesMatch;
	}

	private Object decodeParameter(Object parameter, Class parameterType) {

		boolean setType = false;

		DecoderFactory decoderFactory = DecoderFactory.getInstance();

		if (parameter instanceof ASObject
			&& ((ASObject) parameter).getType() == null) {

			setType = true;
			((ASObject) parameter).setType(parameterType.getName());
		}

		ActionScriptDecoder decoder =
			decoderFactory.getDecoder(parameter, parameterType);
		Object decodedObject = decoder.decodeObject(parameter, parameterType);

		if (!setType
			&& decodedObject == null
			&& parameter instanceof ASObject) {
			((ASObject) parameter).setType(parameterType.getName());
			decodedObject = decoder.decodeObject(parameter, parameterType);
		}
		return decodedObject;
	}

	public int compareTo(Object o) {

		int compareTo = 0;
		RankedMethod rankedMethod = (RankedMethod) o;
		
		if (getRank() > rankedMethod.getRank()) {
			compareTo = -1;
		} else if (getRank() < rankedMethod.getRank()) {
			compareTo = 1;
		}

		return compareTo;
	}

}