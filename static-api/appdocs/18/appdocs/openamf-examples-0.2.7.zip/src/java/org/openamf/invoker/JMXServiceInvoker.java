package org.openamf.invoker;

import java.util.List;

import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.ObjectName;
import javax.servlet.ServletContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openamf.ServiceRequest;

public class JMXServiceInvoker extends ServiceInvoker {

	private static Log log = LogFactory.getLog(JMXServiceInvoker.class);

	public JMXServiceInvoker(
		ServiceRequest request,
		ServletContext servletContex) {
			
		super(request, servletContex);
	}

	public Object invokeService() throws ServiceInvocationException {

		Object serviceResult = null;
		List serverList = MBeanServerFactory.findMBeanServer(null);
		MBeanServer server = (MBeanServer) serverList.iterator().next();	

		try {
			ObjectName objectName = new ObjectName(request.getServiceName());
			Object[] parameters = request.getParameters().toArray();
			String[] signature = new String[parameters.length];

			for (int i = 0; i < parameters.length; i++) {
				signature[i] = parameters[i].getClass().getName();
			}
			serviceResult =
				server.invoke(
					objectName,
					request.getServiceMethodName(),
					parameters,
					signature);
		} catch (Exception e) {
			throw new ServiceInvocationException(request, e);
		}

		return serviceResult;
	}

	public boolean getPersistService() {
		return false;
	}

	public String getPersistantServiceName() {
		return null;
	}

	public boolean supports(ServiceRequest request) {
		return (request.getServiceName().lastIndexOf(":") != -1);
	}

}
