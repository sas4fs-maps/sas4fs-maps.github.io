package org.openamf.test;

public class TestBean {
	
	private String testValue;

	/**
	 * Returns the testValue.
	 * @return String
	 */
	public String getTestValue() {
		return testValue;
	}

	/**
	 * Sets the testValue.
	 * @param testValue The testValue to set
	 */
	public void setTestValue(String testValue) {
		this.testValue = testValue;
	}

}
