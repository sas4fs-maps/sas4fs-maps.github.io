package org.openamf;

import java.util.ArrayList;

import org.openamf.config.ServiceConfig;
import org.openamf.config.ServiceMethodConfig;

public class ServiceRequest {

	private AMFBody requestBody;
	private ServiceConfig serviceConfig;
	private ServiceMethodConfig methodConfig;
	private String target;
	private String serviceName;
	private String serviceMethodName;
	private ArrayList parameters;

	public ServiceRequest(AMFBody requestBody) {
		this(requestBody, null);
	}

	public ServiceRequest(AMFBody requestBody, ServiceConfig serviceConfig) {
		this.requestBody = requestBody;
		this.serviceConfig = serviceConfig;
		this.target = requestBody.getTarget();
		if (serviceConfig == null) {
			this.serviceName = requestBody.getServiceName();
		} else {
			this.serviceName = serviceConfig.getServiceLocation();
		}
		this.serviceMethodName = requestBody.getServiceMethodName();

		Object value = requestBody.getValue();
		if (value != null && value instanceof ArrayList) {
			this.parameters = (ArrayList) value;
		}
	}

	public AMFBody getRequestBody() {
		return requestBody;
	}

	public void setRequestBody(AMFBody body) {
		requestBody = body;
	}
	
	public ServiceConfig getServiceConfig() {
		return serviceConfig;
	}

	public ServiceMethodConfig getServiceMethodConfig() {
		return methodConfig;
	}
	
	void setServiceMethodConfig(ServiceMethodConfig methodConfig) {
		this.methodConfig = methodConfig;
	}
	
	public String getTarget() {
		return target;
	}

	public void setTarget(String string) {
		target = string;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String string) {
		serviceName = string;
	}

	public String getServiceMethodName() {
		return serviceMethodName;
	}

	public void setServiceMethodName(String string) {
		serviceMethodName = string;
	}

	public ArrayList getParameters() {
		return parameters;
	}

	public void setParameters(ArrayList list) {
		parameters = list;
	}

	public void addParameter(Object stateBean) {
		parameters.add(stateBean);
	}


}
