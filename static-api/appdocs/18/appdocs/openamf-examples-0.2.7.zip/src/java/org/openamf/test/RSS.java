package org.openamf.test;

import java.io.IOException;

import org.apache.commons.digester.rss.Channel;
import org.apache.commons.digester.rss.RSSDigester;
import org.xml.sax.SAXException;

public class RSS {

	public Channel getChannel(String rssURL) throws IOException, SAXException {

		Channel channel = null;

		RSSDigester digester = new RSSDigester();

		channel = (Channel) digester.parse(rssURL);

		return channel;
	}

}
