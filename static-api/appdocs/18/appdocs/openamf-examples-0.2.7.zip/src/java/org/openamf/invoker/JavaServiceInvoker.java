package org.openamf.invoker;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.ServletContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openamf.ServiceRequest;

public class JavaServiceInvoker extends ServiceInvoker {

	private static Log log = LogFactory.getLog(JavaServiceInvoker.class);

	public JavaServiceInvoker(
		ServiceRequest request,
		ServletContext servletContex) {

		super(request, servletContex);
	}

	public Object invokeService() throws ServiceInvocationException {

		Class serviceClass = null;
		Object service = null;
		Object serviceResult = null;

		try {
			serviceClass =
				Thread.currentThread().getContextClassLoader().loadClass(
					request.getServiceName());
			service = persistantServiceObject;
			if (service == null) {
				service = serviceClass.newInstance();
			}
			serviceResult =
				invokeServiceMethod(
					service,
					serviceClass,
					request.getServiceMethodName(),
					request.getParameters());
			persistantServiceObject = service;
		} catch (Exception e) {
			throw new ServiceInvocationException(request, e);
		}

		return serviceResult;
	}

	public boolean getPersistService() {
		return true;
	}

	public String getPersistantServiceName() {
		return request.getServiceName();
	}

	protected Object invokeServiceMethod(
		Object service,
		Class serviceClass,
		String methodName,
		List parameters)
		throws
			SecurityException,
			NoSuchMethodException,
			IllegalArgumentException,
			IllegalAccessException,
			InvocationTargetException {

		RankedMethod serviceMethod =
			getServiceMethod(serviceClass, methodName, parameters);

		return serviceMethod.invoke(service);

	}

	private RankedMethod getServiceMethod(
		Class serviceClass,
		String methodName,
		List parameters)
		throws SecurityException, NoSuchMethodException {

		RankedMethod serviceMethod = null;
		Method[] methods = serviceClass.getMethods();
		ArrayList rankedMethods = new ArrayList(methods.length);

		log.debug("REQUESTED methodName: " + methodName);
		
		for (int i = 0; i < methods.length; i++) {
			Method method = methods[i];
			RankedMethod rankedMethod =
				new RankedMethod(method, methodName, parameters);
			if (rankedMethod.isInvokable()) {
				//only added invokable methods to list
				rankedMethods.add(rankedMethod);
			}
		}

		if (rankedMethods.size() > 0) {
			log.debug("rankedMethods.size() = " + rankedMethods.size());
			Collections.sort(rankedMethods);
			RankedMethod topRankedMethod = (RankedMethod) rankedMethods.get(0);
			log.debug("topRankedMethod rank = " + topRankedMethod.getRank());
			serviceMethod = topRankedMethod;
		}

		if (serviceMethod == null) {
			throw new NoSuchMethodException();
		}

		return serviceMethod;
	}

	public boolean supports(ServiceRequest request) {

		boolean supports = false;
		try {
			Thread.currentThread().getContextClassLoader().loadClass(
				request.getServiceName());
			supports = true;
		} catch (Exception e) {
		}

		return supports;
	}

}
