package org.openamf;

public class ASObject extends flashgateway.io.ASObject {
	
	public ASObject() {
		super();
	}
	
	public ASObject(String type) {
		super(type);
	}

}
