package org.openamf;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openamf.config.Config;
import org.openamf.config.ConfigDigester;
import org.openamf.config.ServiceInvokerConfig;
import org.openamf.invoker.ServiceInvocationException;
import org.openamf.invoker.ServiceInvoker;
import org.openamf.io.AMFDeserializer;
import org.openamf.io.AMFSerializer;
import org.xml.sax.SAXException;

public class DefaultGateway extends HttpServlet {

	protected static Log log = LogFactory.getLog(DefaultGateway.class);

	private static final String OPENAMF_CONFIG = "OPENAMF_CONFIG";

	public void service(
		HttpServletRequest httpServletRequest,
		HttpServletResponse httpServletResponse)
		throws ServletException, IOException {

		DataInputStream inputStream =
			new DataInputStream(httpServletRequest.getInputStream());

		AMFDeserializer des = new AMFDeserializer(inputStream);
		AMFMessage requestMessage = des.getAMFMessage();

		debugRequestMessage(requestMessage);

		processMessage(httpServletRequest, httpServletResponse, requestMessage);
	}

	private void debugRequestMessage(AMFMessage requestMessage) {

		if (log.isDebugEnabled()) {
			int headerCount = requestMessage.getHeaderCount();
			for (int i = 0; i < headerCount; i++) {
				AMFHeader header = requestMessage.getHeaderAt(i);
				log.debug(header.getKey() + " = " + header.getValue());
			}

			int bodyCount = requestMessage.getBodyCount();
			for (int i = 0; i < bodyCount; i++) {
				AMFBody body = requestMessage.getBodyAt(i);
				log.debug("Body " + i);
				log.debug("target = " + body.getTarget());
				log.debug("response = " + body.getResponse());
				log.debug("value class = " + body.getValue().getClass());
				log.debug("value = " + body.getValue());
			}
		}
	}

	private void processMessage(
		HttpServletRequest httpServletRequest,
		HttpServletResponse httpServletResponse,
		AMFMessage requestMessage)
		throws IOException {

		ByteArrayOutputStream baOutputStream = new ByteArrayOutputStream();
		DataOutputStream outputStream = new DataOutputStream(baOutputStream);

		for (Iterator bodies = requestMessage.getBodies(); bodies.hasNext();) {
			AMFBody requestBody = (AMFBody) bodies.next();
			Object serviceResult = null;

			try {
				ServiceInvoker serviceInvoker =
					getServiceInvoker(requestBody, httpServletRequest);
				preInvokeService(httpServletRequest, serviceInvoker);
				serviceResult = serviceInvoker.invokeService();
				serviceResult =
					postInvokeService(
						httpServletRequest,
						serviceInvoker,
						serviceResult);
			} catch (ServiceInvocationException e) {
				serviceResult = e.getAMFError();
				e.getCause().printStackTrace();
			}

			if (serviceResult == null) {
				log.debug("RESULT IS NULL!");
			} else {
				sendResponse(requestBody, outputStream, serviceResult);
			}
		}

		httpServletResponse.setContentType("application/x-amf");
		httpServletResponse.setContentLength(baOutputStream.size());
		baOutputStream.writeTo(httpServletResponse.getOutputStream());
		outputStream.flush();
	}

	protected void preInvokeService(
		HttpServletRequest httpServletRequest,
		ServiceInvoker serviceInvoker)
		throws ServiceInvocationException {

		if (serviceInvoker.getPersistService()) {
			Object persistantServiceObject =
				httpServletRequest.getSession().getAttribute(
					serviceInvoker.getPersistantServiceName());

			serviceInvoker.setPersistantServiceObject(persistantServiceObject);
		}
	}

	protected Object postInvokeService(
		HttpServletRequest httpServletRequest,
		ServiceInvoker serviceInvoker,
		Object serviceResult)
		throws ServiceInvocationException {

		if (serviceInvoker.getPersistService()) {
			httpServletRequest.getSession().setAttribute(
				serviceInvoker.getPersistantServiceName(),
				serviceInvoker.getPersistantServiceObject());
		}

		return serviceResult;
	}

	protected ServiceInvoker getServiceInvoker(
		AMFBody requestBody,
		HttpServletRequest httpServletRequest)
		throws ServiceInvocationException {

		ServiceInvoker serviceInvoker = null;
		ServiceRequest request = new ServiceRequest(requestBody);

		try {
			for (Iterator i = getConfig().getServiceInvokerConfigs();
				i.hasNext();
				) {

				ServiceInvokerConfig invokerConfig =
					(ServiceInvokerConfig) i.next();

				log.debug(
					"Checking if the "
						+ invokerConfig.getName()
						+ " Service Invoker can support the request");

				ServiceInvoker tempInvoker =
					ServiceInvoker.load(
						invokerConfig.getClassName(),
						request,
						getServletContext());

				if (tempInvoker.supports(request)) {
					serviceInvoker = tempInvoker;
					log.debug("YES");
					break;
				} else {
					log.debug("NO");
				}
			}
		} catch (Exception e) {
			throw new ServiceInvocationException(request, e);
		}

		return serviceInvoker;
	}

	protected Config getConfig() throws IOException, SAXException {
	
		Config config = (Config)getServletContext().getAttribute(OPENAMF_CONFIG);
	
		if (config == null) {
			String configLocation =
				getServletConfig().getInitParameter(OPENAMF_CONFIG);
			InputStream inputStream =
				getServletContext().getResourceAsStream(configLocation);

			ConfigDigester configDigester = new ConfigDigester();
			configDigester.setUseContextClassLoader(true);
			
			config = (Config) configDigester.parse(inputStream);

			getServletContext().setAttribute(OPENAMF_CONFIG, config);
			log.debug("Putting config in Servlet Context");
			if (log.isDebugEnabled()) {
				log.debug(config);
			}
		}

		return config;
	}

	private void sendResponse(
		AMFBody requestBody,
		DataOutputStream outputStream,
		Object serviceResult)
		throws IOException {

		String response = "/onResult";
		if (serviceResult instanceof AMFError) {
			response = "/onStatus";
		}

		AMFMessage responseMessage = new AMFMessage();
		AMFBody responseBody =
			new AMFBody(
				requestBody.getResponse() + response,
				"null",
				serviceResult);
		responseMessage.addBody(responseBody);

		AMFSerializer serializer = new AMFSerializer(outputStream);
		serializer.serialize(responseMessage);
	}
}
