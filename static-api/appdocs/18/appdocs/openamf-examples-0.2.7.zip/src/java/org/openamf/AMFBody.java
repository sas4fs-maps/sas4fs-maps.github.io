package org.openamf;


public class AMFBody {
	
	protected String target;
	protected String serviceName;
	protected String serviceMethodName;
	protected String response;
	protected Object value;
	protected byte type;
	
	public static final byte DATA_TYPE_UNKNOWN = -1;
	public static final byte DATA_TYPE_NUMBER = 0;
	public static final byte DATA_TYPE_BOOLEAN = 1;
	public static final byte DATA_TYPE_STRING = 2;
	public static final byte DATA_TYPE_OBJECT = 3;
	public static final byte DATA_TYPE_NULL = 5;
	public static final byte DATA_TYPE_FLUSHED_SHARED_OBJECT = 7;
	public static final byte DATA_TYPE_ARRAY_SHARED_OBJECT = 8;
	public static final byte DATA_TYPE_ARRAY = 10;
	public static final byte DATA_TYPE_DATE = 11;
	public static final byte DATA_TYPE_AS_OBJECT = 13;
	public static final byte DATA_TYPE_XML = 15;
	public static final byte DATA_TYPE_CUSTOM_CLASS = 16;

	public AMFBody(String target, String response, Object value) {
		this(target, response, value, DATA_TYPE_UNKNOWN);
	}

	public AMFBody(String target, String response, Object value, byte type) {
		this.target = target;
		this.response = response;
		this.value = value;
		this.type = type;
		
		int dotIndex = target.lastIndexOf('.');
		if (dotIndex > 0) {
			this.serviceName = target.substring(0, dotIndex);
			this.serviceMethodName = target.substring(dotIndex + 1);
		}
	}

	public String getTarget() {
		return target;
	}

	public void setTarget(String target) {
		this.target = target;
	}
	
	public String getServiceName() {
		return serviceName;
	}

	public String getServiceMethodName() {
		return serviceMethodName;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

	public byte getType() {
		return type;
	}

	public void setType(byte type) {
		this.type = type;
	}
	
}