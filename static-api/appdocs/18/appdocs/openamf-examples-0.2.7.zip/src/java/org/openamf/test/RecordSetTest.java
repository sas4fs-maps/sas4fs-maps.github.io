package org.openamf.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openamf.recordset.ASRecordSet;

public class RecordSetTest {

	private static Log log = LogFactory.getLog(RecordSetTest.class);

	/**
	 * Normally you would return a java.sql.ResultSet, 
	 * but since this is a test I want to make sure a
	 * RecordSet comes back 
	 * 
	 * @param sql
	 * @param dbURL
	 * @param jdbcDriver
	 * @return
	 */
	public ASRecordSet getData(String sql, String dbURL, String jdbcDriver) {

		ASRecordSet asRecordSet = new ASRecordSet();

		Connection conn = null;

		try {
			conn = getConnection(dbURL, jdbcDriver);
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			asRecordSet.populate(rs);
			log.debug("populated asRecordSet with rs");
			rs.close();
			stmt.close();
		} catch (Exception e) {
			log.error("Unable to execute sql", e);
			// return error as record set
			int rowCount = 25;
			ArrayList rows = new ArrayList();
			for (int i = 0; i < rowCount; i++) {
				ArrayList row = new ArrayList();
				row.add(e.getMessage() + (i + 1));
				row.add(sql + (i + 1));
				row.add(dbURL + (i + 1));
				rows.add(row);
			}
			asRecordSet.populate(new String[]{"Error", "SQL", "dbUrl"},  rows);
			log.debug("populated asRecordSet with rows");
		}

		return asRecordSet;

	}

	private Connection getConnection(String dbURL, String jdbcDriver)
		throws
			ClassNotFoundException,
			InstantiationException,
			IllegalAccessException,
			SQLException {

		Connection conn = null;

		//Load driver
		Class.forName(jdbcDriver).newInstance();

		conn = DriverManager.getConnection(dbURL);

		return conn;
	}

	public static void main(String[] args) {
		ASRecordSet asRecordSet =
			new RecordSetTest().getData(
				"Select * from users",
				"jdbc:mysql://localhost/openamf?user=openamf&password=openamf",
				"com.mysql.jdbc.Driver");
				
		System.out.println(asRecordSet);
	}

}
