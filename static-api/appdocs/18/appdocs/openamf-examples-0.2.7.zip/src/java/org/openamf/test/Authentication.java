package org.openamf.test;

import java.io.Serializable;

public class Authentication implements Serializable {

}
