package org.openamf.config;

import java.util.ArrayList;
import java.util.Iterator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ServiceMethodConfig {
	
	private String name;
	private ArrayList stateBeanRefs = new ArrayList();
	private ArrayList stateBeanConfigs = new ArrayList();
	private boolean stateBeanConfigsLoaded = false;
	private ArrayList parameterConfigs = new ArrayList();
	private ArrayList resultFilterConfigs = new ArrayList();
	private ServiceConfig serviceConfig;
	
	private static Log log = LogFactory.getLog(ServiceMethodConfig.class);

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void addStateBeanRef(String name) {
		log.debug("Adding stateBeanRef");
		stateBeanRefs.add(name);
	}
	
	public Iterator getStateBeanConfigs() {
		
		if (getConfig() == null) {
			return null;
		}
		
		if (!stateBeanConfigsLoaded) {
			for (Iterator iterator = stateBeanRefs.iterator(); iterator.hasNext();) {
				String name = (String) iterator.next();
				StateBeanConfig stateBeanConfig = getConfig().getStateBeanConfig(name);
				stateBeanConfigs.add(stateBeanConfig);
			}
			stateBeanConfigsLoaded = true;
		}
		return stateBeanConfigs.iterator();
	}
	
	public Iterator getParameterConfigs() {
		return parameterConfigs.iterator();
	}
	
	public void addParameterConfig(ServiceMethodParameterConfig parameterConfig) {
		parameterConfigs.add(parameterConfig);
	}

	public Iterator getResultFilterConfigs() {
		if (getServiceConfig() == null) {
			return null;
		}
		return resultFilterConfigs.iterator();
	}

	public void  addResultFilterConfig(FilterConfig resultFilterConfig) {
		resultFilterConfigs.add(resultFilterConfig);
	}

	public Config getConfig() {
		if (getServiceConfig() == null) {
			return null;
		}
		return getServiceConfig().getConfig();
	}
	
	public ServiceConfig getServiceConfig() {
		return serviceConfig;
	}
	
	public void setServiceConfig(ServiceConfig serviceConfig) {
		this.serviceConfig = serviceConfig;
	}

	public String toString() {
		
		if (getServiceConfig() == null) {
			return super.toString();
		}
		
		StringBuffer sb = new StringBuffer();
		
		sb.append("\tName: ");
		sb.append(getName());
		sb.append('\n');

		sb.append("\t-----------------\n");
		sb.append("\tSTATE BEANS\n");
		sb.append("\t-----------------\n");
		for (Iterator i = getStateBeanConfigs(); i.hasNext();) {
			StateBeanConfig sbc = (StateBeanConfig)i.next();
			sb.append(sbc);
		}
		
		sb.append("\t-----------------\n");
		sb.append("\tPARAMETERS\n");
		sb.append("\t-----------------\n");
		for (Iterator i = getParameterConfigs(); i.hasNext();) {
			ServiceMethodParameterConfig smpc = (ServiceMethodParameterConfig)i.next();
			sb.append(smpc);
		}

		sb.append("\t-----------------\n");
		sb.append("\tRESULT FILTERS:\n");
		sb.append("\t-----------------\n");
		for (Iterator i = getResultFilterConfigs(); i.hasNext();) {
			FilterConfig fc = (FilterConfig)i.next();
			sb.append(fc);
		}

		return sb.toString();
	}

}
