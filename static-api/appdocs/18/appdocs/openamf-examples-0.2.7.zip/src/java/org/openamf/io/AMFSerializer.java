package org.openamf.io;

import java.beans.PropertyDescriptor;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.TimeZone;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openamf.AMFBody;
import org.openamf.AMFMessage;
import org.openamf.ASObject;
import org.openamf.recordset.ASRecordSet;
import org.openamf.util.XMLUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

//TODO: use http://www.php.net/manual/en/function.pack.php to convert php
// serialization to java

public class AMFSerializer {

	protected static Log log = LogFactory.getLog(AMFSerializer.class);

	private static final int MILLS_PER_HOUR = 60000;

	// Data
	protected AMFMessage message;

	// The output stream
	protected DataOutputStream outputStream;

	public AMFSerializer(DataOutputStream outputStream) {
		this.outputStream = outputStream;
	}

	public void serialize(AMFMessage message) throws IOException {
		this.message = message;

		// Write the version?
		outputStream.writeShort(0);

		// Get the header count
		int count = message.getHeaderCount();
		// Write the header count
		outputStream.writeShort(count);

		// Now write the headers
		for (int i = 0; i < count; i++)
			writeHeader(i);

		count = message.getBodyCount();
		// Write the body count
		outputStream.writeShort(count);

		// Now write the bodies
		for (int i = 0; i < count; i++)
			writeBody(i);
	}

	public void writeHeader(int i) {
		// Write the headers to the output stream
		// Nothing for now
	}

	public void writeBody(int i) throws IOException {
		AMFBody body = message.getBodyAt(i);
		outputStream.writeUTF(body.getTarget());
		outputStream.writeUTF(body.getResponse());
		// Always, always there is four bytes of FF, which is -1 of course
		outputStream.writeInt(-1);
		// Write the data to the output stream
		writeData(body.getValue());
	}

	public void writeData(Object value) throws IOException {
		if (value == null) {
			outputStream.writeByte(AMFBody.DATA_TYPE_NULL);
		} else if (value instanceof Number) {
			outputStream.writeByte(AMFBody.DATA_TYPE_NUMBER);
			outputStream.writeDouble(((Number) value).doubleValue());
		} else if (value instanceof String) {
			outputStream.writeByte(AMFBody.DATA_TYPE_STRING);
			outputStream.writeUTF((String) value);
		} else if (value instanceof Boolean) {
			outputStream.writeByte(AMFBody.DATA_TYPE_BOOLEAN);
			outputStream.writeBoolean(((Boolean) value).booleanValue());
		} else if (value instanceof Date) {
			outputStream.writeByte(AMFBody.DATA_TYPE_DATE);
			outputStream.writeDouble(((Date) value).getTime());
			int offset = TimeZone.getDefault().getRawOffset();
			outputStream.writeShort(offset / MILLS_PER_HOUR);
		} else if (value instanceof Object[]) {
			writeArray(value);
		} else if (value instanceof Collection) {
			writeCollection(value);
		} else if (value instanceof Map) {
			writeMap(value);
		} else if (value instanceof ResultSet) {
			ASRecordSet asRecordSet = new ASRecordSet();
			asRecordSet.populate((ResultSet) value);
			writeData(asRecordSet);
		} else if (value instanceof Document) {
			writeXML((Document) value);
		} else {
			/*
			MM's gateway requires all objects to be marked with the 
			Serializable interface in order to be serialized
			That should still be followed if possible, but there is
			no good reason to inforce it.
			*/
			writeObject(value);
		}
	}

	private void writeObject(Object object) throws IOException {

		outputStream.writeByte(AMFBody.DATA_TYPE_OBJECT);
		try {
			PropertyDescriptor[] properties =
				PropertyUtils.getPropertyDescriptors(object);
			for (int i = 0; i < properties.length; i++) {
				if (!properties[i].getName().equals("class")) {
					String propertyName = properties[i].getName();
					Method readMethod = properties[i].getReadMethod();
					Object propertyValue =
						readMethod.invoke(object, new Object[0]);
					log.debug(propertyName + " = " + propertyValue);
					outputStream.writeUTF(propertyName);
					writeData(propertyValue);
				}
			}
			outputStream.writeShort(0);
			outputStream.writeByte(9);
		} catch (Exception e) {
			throw new IOException(e.getMessage());
		}
	}

	private void writeArray(Object value) throws IOException {
		Object[] array = (Object[]) value;

		log.debug("size = " + array.length);
		System.out.println("size = " + array.length);

		outputStream.writeByte(AMFBody.DATA_TYPE_ARRAY);

		outputStream.writeInt(array.length);

		for (int i = 0; i < array.length; i++) {
			Object object = array[i];
			writeData(object);
		}
	}

	private void writeCollection(Object value) throws IOException {
		Collection collection = (Collection) value;

		log.debug("size = " + collection.size());

		outputStream.writeByte(AMFBody.DATA_TYPE_ARRAY);

		outputStream.writeInt(collection.size());

		for (Iterator objects = collection.iterator(); objects.hasNext();) {
			Object object = objects.next();
			writeData(object);
		}
	}

	private void writeMap(Object value) throws IOException {
		Map map = (Map) value;

		if (value instanceof ASObject
			&& ((ASObject) value).getType() != null) {
			log.debug("Writting Custom Class: " + ((ASObject) value).getType());
			outputStream.writeByte(AMFBody.DATA_TYPE_CUSTOM_CLASS);
			outputStream.writeUTF(((ASObject) value).getType());
		} else {
			log.debug("Writting Map");
			outputStream.writeByte(AMFBody.DATA_TYPE_OBJECT);
		}
		log.debug("size = " + map.entrySet().size());
		for (Iterator entrys = map.entrySet().iterator(); entrys.hasNext();) {
			Map.Entry entry = (Map.Entry) entrys.next();
			log.debug(entry.getKey().toString() + ": " + entry.getValue());
			outputStream.writeUTF(entry.getKey().toString());
			writeData(entry.getValue());
		}
		outputStream.writeShort(0);
		outputStream.writeByte(9);
	}

	private void writeXML(Document document) throws IOException {
		outputStream.writeByte(AMFBody.DATA_TYPE_XML);
		Element docElement = document.getDocumentElement();
		String xmlData = XMLUtils.convertDOMToString(docElement);
		log.debug("xmlData: \n" + xmlData);
		ByteArrayOutputStream baOutputStream = new ByteArrayOutputStream();
		baOutputStream.write(xmlData.getBytes());
		outputStream.writeInt(baOutputStream.size());
		baOutputStream.writeTo(outputStream);
	}

}