package org.openamf.filter;

import org.openamf.config.FilterConfig;

public interface ResultFilter {
	
	public Object filter(Object value, FilterConfig config) throws FilterException;

}
