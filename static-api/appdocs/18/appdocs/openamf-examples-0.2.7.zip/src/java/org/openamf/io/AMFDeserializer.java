package org.openamf.io;

import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openamf.AMFBody;
import org.openamf.AMFMessage;
import org.openamf.ASObject;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

public class AMFDeserializer {

	protected static Log log = LogFactory.getLog(AMFDeserializer.class);

	// The AMF input stream
	protected DataInputStream inputStream;

	// Number of headers in the packet
	protected int headerCount;

	// Content of the headers
	protected ArrayList headers;

	// Number of bodies
	protected int bodyCount;

	// Content of the bodies
	protected ArrayList bodies;

	// Object to store the deserialized data
	protected AMFMessage message;

	public AMFDeserializer(DataInputStream inputStream) throws IOException {
		message = new AMFMessage();

		// Save the input stream for this object
		this.inputStream = inputStream;
		// Read the binary header
		readHeader();
		log.debug("readHeader");
		// Read the binary body
		readBody();
		log.debug("readBody");
	}

	public AMFMessage getAMFMessage() {
		return message;
	}

	protected void readHeader() throws IOException {
		// Ignore the first two bytes - version or something
		inputStream.readUnsignedShort();
		// Find total number of header elements
		headerCount = inputStream.readUnsignedShort();
		log.debug("headerCount = " + headerCount);

		// Loop over all the header elements
		for (int i = 0; i < headerCount; i++) {
			String name = inputStream.readUTF();
			// Find the must understand flag
			boolean required = readBoolean();
			// Grab the length of the header element
			long length = inputStream.readInt();
			// Grab the type of the element
			byte type = inputStream.readByte();
			// Turn the element into real data
			Object content = readData(type);
			// Save the name/value into the headers array
			message.addHeader(name, required, content);
		}
	}

	protected void readBody() throws IOException {
		// Find the total number of body elements
		bodyCount = inputStream.readUnsignedShort();
		log.debug("bodyCount = " + bodyCount);

		// Loop over all the body elements
		for (int i = 0; i < bodyCount; i++) {
			String method = readString();
			// The target that the client understands
			String target = readString();
			// Get the length of the body element
			long length = inputStream.readInt();
			// Grab the type of the element
			byte type = inputStream.readByte();

			log.debug("type = " + type);

			//log.debug("Length InnerObject " + inputStream.readInt());
			//type = inputStream.readByte();
			//log.debug("Type InnerObject " + type);			

			// Turn the argument elements into real data
			Object data = readData(type);
			// Add the body element to the body object
			message.addBody(method, target, data, type);
		}
	}

	protected Object readCustomClass() throws IOException {
		// Grab the explicit type - somehow it works
		String type = inputStream.readUTF();
		ASObject aso = new ASObject(type);
		
		// The rest of the bytes are an object without the 0x03 header
		return readObject(aso);
	}

	protected ASObject readObject() throws IOException {
		ASObject aso = new ASObject();
		return readObject(aso);
	}
	// Reads an object and converts the binary data into an ArrayList
	protected ASObject readObject(ASObject aso) throws IOException {
		// Init the array
		log.debug("reading object");

		// Grab the key
		String key = inputStream.readUTF();

		for (byte type = inputStream.readByte();
			type != 9;
			type = inputStream.readByte()) {
			// Grab the value
			Object value = readData(type);
			// Save the name/value pair in the map
			aso.put(key, value);
			log.debug(
				" adding {key="
					+ key
					+ ", value="
					+ value
					+ ", type="
					+ type
					+ "}");
			// Get the next name
			key = inputStream.readUTF();
		}

		log.debug("finished reading object");
		// Return the map
		return aso;
	}

	protected ArrayList readArray() throws IOException {
		// Init the array
		ArrayList array = new ArrayList();
		log.debug("reading array");
		// Grab the length of the array
		long length = inputStream.readInt();
		log.debug("array length = " + length);

		// Loop over all the elements in the data
		for (long i = 0; i < length; i++) {
			// Grab the type for each element
			byte type = inputStream.readByte();
			log.debug("type = " + type);
			// Grab the element
			array.add(readData(type));
		}

		// Return the data
		return array;
	}

	protected double readNumber() throws IOException {
		return inputStream.readDouble();
	}

	// Read the next byte and return its boolean value
	protected boolean readBoolean() throws IOException {
		byte value = inputStream.readByte();

		// If it's a 0x01 return true, else return false
		if (value == 1)
			return true;
		else
			return false;
	}

	protected String readString() throws IOException {
		return inputStream.readUTF();
	}

	protected Date readDate() throws IOException {
		double ms = inputStream.readDouble(); // Date in millis from 01/01/1970

		int timeoffset = inputStream.readUnsignedShort();
		if (timeoffset > 720) {
			// I haven't tested this
			timeoffset = - (65536 - timeoffset);
		}

		ms += (double) timeoffset;
		Date date = new Date((long) ms);

		return date;
	}

	protected Document readXML() throws IOException {
		Document document = null;
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

		inputStream.skip(4); // skip length 
		try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			document = builder.parse(new InputSource(inputStream));
		} catch (Exception e) {
			throw new IOException(e.getMessage());
		}
		return document;
	}

	protected int readFlushedSO() throws IOException {
		return inputStream.readInt();
	}

	protected Object readASObject() {
		return null;
	}

	protected Object readData(byte type) throws IOException {
		Object data = null;

		switch (type) {
			case AMFBody.DATA_TYPE_NUMBER :
				data = new Double(readNumber());
				break;
			case AMFBody.DATA_TYPE_BOOLEAN :
				data = new Boolean(readBoolean());
				break;
			case AMFBody.DATA_TYPE_STRING :
				data = readString();
				break;
			case AMFBody.DATA_TYPE_OBJECT :
				data = readObject();
				break;
			case AMFBody.DATA_TYPE_NULL :
				data = null;
				break;
			case AMFBody.DATA_TYPE_FLUSHED_SHARED_OBJECT :
				data = new Integer(readFlushedSO());
				break;
			case AMFBody.DATA_TYPE_ARRAY_SHARED_OBJECT :
				break;
			case AMFBody.DATA_TYPE_ARRAY :
				data = readArray();
				break;
			case AMFBody.DATA_TYPE_DATE :
				data = readDate();
				break;
			case AMFBody.DATA_TYPE_AS_OBJECT :
				data = readASObject();
				break;
			case AMFBody.DATA_TYPE_XML :
				data = readXML();
				break;
			case AMFBody.DATA_TYPE_CUSTOM_CLASS :
				data = readCustomClass();
				break;
			default :
				data = null;
				break;
		}

		return data;
	}
}