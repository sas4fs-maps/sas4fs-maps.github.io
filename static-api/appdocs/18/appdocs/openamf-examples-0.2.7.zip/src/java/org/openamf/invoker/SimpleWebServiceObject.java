package org.openamf.invoker;

//import java.util.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
/*
import javax.wsdl.extensions.soap.SOAPAddress;
import javax.wsdl.extensions.soap.SOAPBody;
import javax.wsdl.extensions.soap.SOAPBinding;
*/

public class SimpleWebServiceObject {


private String uri=null;
private String endpoint=null;
private String [] parms=null;

private static Log log = LogFactory.getLog(SimpleWebServiceObject.class);


public SimpleWebServiceObject()
{

	
}

public String[] getArgs()
{
	return parms;
}
public void setArgs(String[] args)
{
	parms=args;
}


public void setEndpoint(String value)
{
	endpoint=value;
}
public void setNamespaceURI(String value)
{
	uri=value;
}

public String getEndpoint()
{
	return endpoint;
}
public String getNamespaceURI()
{
	return uri;
}



}
