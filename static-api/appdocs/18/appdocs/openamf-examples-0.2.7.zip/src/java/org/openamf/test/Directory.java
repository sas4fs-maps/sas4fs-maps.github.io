package org.openamf.test;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class Directory implements Serializable {

	protected static Log log = LogFactory.getLog(Directory.class);

	private ArrayList people = new ArrayList();

	public void addPerson(Person person) {
		addPerson(person, null);
	}

	public void addPerson(Person person, Authentication authentication) {
		log.debug("Adding " + person + " to Directory ");
		if (authentication != null) {
			log.debug("got authentication");
		}
		people.add(person);
	}

	public ArrayList getPeople(String name) {
		return getPeople(name, null);
	}
	
	public ArrayList getPeople(String name, Authentication authentication) {

		log.debug("getPeople(" + name + ")");
		if (authentication != null) {
			log.debug("got authentication");
		}

		ArrayList result = new ArrayList();

		for (Iterator iter = people.iterator(); iter.hasNext();) {
			Person person = (Person) iter.next();
			if (person.getFirstName().equals(name)
				|| person.getLastName().equals(name)) {
				log.debug("Adding " + person + " to result");
				result.add(person);
			}
		}

		return result;

	}

	public ArrayList getPeople(int zipCode) {
		return getPeople(zipCode, null);
	}

	public ArrayList getPeople(int zipCode, Authentication authentication) {

		log.debug("getPeople(" + zipCode + ")");
		if (authentication != null) {
			log.debug("got authentication");
		}
		ArrayList result = new ArrayList();

		for (Iterator iter = people.iterator(); iter.hasNext();) {
			Person person = (Person) iter.next();
			if (person.getZipCode() == zipCode) {
				log.debug("Adding " + person + " to result");
				result.add(person);
			}
		}

		return result;

	}

}
