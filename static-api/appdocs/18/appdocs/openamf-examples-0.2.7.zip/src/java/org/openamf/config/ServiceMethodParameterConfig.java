package org.openamf.config;

public class ServiceMethodParameterConfig {
	
	private String type;
	
	public String getType() {
		return type; 
	}
	
	public void setType(String type) {
		this.type = type;
	}

	public String toString() {
		
		StringBuffer sb = new StringBuffer();
		
		sb.append("\t\t\tType: ");
		sb.append(getType());
		sb.append('\n');

		return sb.toString();
	}


}
