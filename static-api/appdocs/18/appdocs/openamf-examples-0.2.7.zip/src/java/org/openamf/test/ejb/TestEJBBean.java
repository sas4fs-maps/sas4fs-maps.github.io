package org.openamf.test.ejb;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

/**
 * @ejb.bean name="TestEJB"
 *	jndi-name="TestEJBBean"
 *	type="Stateless" 
**/
public class TestEJBBean implements SessionBean {

	private SessionContext sessionContext;

	/**
	 * @ejb:create-method
	 */
	public void ejbCreate() throws CreateException {
	}

	/**
	 * @ejb.interface-method
	 *	view-type="remote" 
	**/
	public String getEcho(String value) {
		System.out.println("value " + value);
		return value;
	}

	// -------------------------------------------------------------------------
	// Framework Callbacks
	// -------------------------------------------------------------------------
	public void setSessionContext(SessionContext sessionContext)
		throws EJBException {
		this.sessionContext = sessionContext;
	}

	public void ejbActivate() throws EJBException {
	}

	public void ejbPassivate() throws EJBException {
	}

	public void ejbRemove() throws EJBException {
	}

}
